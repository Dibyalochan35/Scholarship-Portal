<footer class="footer">
      <div class="container">
        <div class="text-center">
Scholarship Management System
        </div>
      </div>
    </footer>