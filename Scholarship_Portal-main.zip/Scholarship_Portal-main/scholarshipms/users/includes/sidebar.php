
<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="dashboard.php">
       
       <h5 class="logo-text">Scholarship Management S/Y</h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li>
        <a href="dashboard.php">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>

     
    

      <li>
        <a href="views-scheme.php">
          <i class="zmdi zmdi-grid"></i> <span>Views Scheme</span>
        </a>
      </li>

      <li>
        <a href="application-history.php">
          <i class="zmdi zmdi-calendar-check"></i> <span>Application History</span>
          
        </a>
      </li>

      <li>
        <a href="profile.php">
          <i class="zmdi zmdi-face"></i> <span>Profile</span>
        </a>
      </li>

      <li>
        <a href="setting.php" target="_blank">
          <i class="zmdi zmdi-lock"></i> <span>Setting</span>
        </a>
      </li>

       <li>
        <a href="logout.php" target="_blank">
          <i class="zmdi zmdi-account-circle"></i> <span>Logout</span>
        </a>
      </li>

     

    </ul>
   
   </div>